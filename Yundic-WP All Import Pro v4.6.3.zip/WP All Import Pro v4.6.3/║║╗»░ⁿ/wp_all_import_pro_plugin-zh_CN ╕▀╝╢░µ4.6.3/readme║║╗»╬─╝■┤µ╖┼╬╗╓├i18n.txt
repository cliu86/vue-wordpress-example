把mo文件放到这个目录：
/wp-content/plugins/本插件名/i18n/languages文件夹里面。

如果网站没有识别，那么放到级别更高的
/wp-content/languages/plugins文件夹里面。