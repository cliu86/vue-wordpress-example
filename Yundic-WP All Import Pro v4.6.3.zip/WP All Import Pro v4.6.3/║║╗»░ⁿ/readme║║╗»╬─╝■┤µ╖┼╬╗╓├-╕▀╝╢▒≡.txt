把汉化文件放到这个目录：

/wp-content/languages/plugins文件夹里面。